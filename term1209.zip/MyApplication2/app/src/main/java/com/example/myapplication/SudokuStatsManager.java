package com.example.myapplication;

import android.content.Context;
import android.content.SharedPreferences;

public class SudokuStatsManager {

    private static final String PREF_NAME = "sudoku_stats";

    private static final String KEY_TOTAL_PLAYS   = "total_plays";
    private static final String KEY_TOTAL_WINS    = "total_wins";
    private static final String KEY_TOTAL_TIME    = "total_time"; // 초 단위 누적

    private static final String KEY_EASY_PLAYS    = "easy_plays";
    private static final String KEY_NORMAL_PLAYS  = "normal_plays";
    private static final String KEY_HARD_PLAYS    = "hard_plays";

    public static void recordGame(Context ctx, String difficulty,
                                  long elapsedSeconds, boolean success) {

        SharedPreferences prefs = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = prefs.edit();

        ed.putInt(KEY_TOTAL_PLAYS, prefs.getInt(KEY_TOTAL_PLAYS, 0) + 1);
        ed.putLong(KEY_TOTAL_TIME, prefs.getLong(KEY_TOTAL_TIME, 0) + elapsedSeconds);
        if (success) {
            ed.putInt(KEY_TOTAL_WINS, prefs.getInt(KEY_TOTAL_WINS, 0) + 1);
        }

        switch (difficulty) {
            case "easy":
                ed.putInt(KEY_EASY_PLAYS, prefs.getInt(KEY_EASY_PLAYS, 0) + 1);
                break;
            case "hard":
                ed.putInt(KEY_HARD_PLAYS, prefs.getInt(KEY_HARD_PLAYS, 0) + 1);
                break;
            default:
                ed.putInt(KEY_NORMAL_PLAYS, prefs.getInt(KEY_NORMAL_PLAYS, 0) + 1);
                break;
        }

        ed.apply();
    }

    public static class Stats {
        public int totalPlays;
        public int totalWins;
        public long totalTime;
        public int easyPlays;
        public int normalPlays;
        public int hardPlays;
    }

    public static Stats loadStats(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        Stats s = new Stats();
        s.totalPlays  = prefs.getInt(KEY_TOTAL_PLAYS, 0);
        s.totalWins   = prefs.getInt(KEY_TOTAL_WINS, 0);
        s.totalTime   = prefs.getLong(KEY_TOTAL_TIME, 0);
        s.easyPlays   = prefs.getInt(KEY_EASY_PLAYS, 0);
        s.normalPlays = prefs.getInt(KEY_NORMAL_PLAYS, 0);
        s.hardPlays   = prefs.getInt(KEY_HARD_PLAYS, 0);
        return s;
    }

    public static void resetAll(Context ctx) {
        ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                .edit().clear().apply();
    }
}
