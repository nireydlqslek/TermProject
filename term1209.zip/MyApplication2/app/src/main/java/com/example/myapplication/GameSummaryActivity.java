package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class GameSummaryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeManager.applyTheme(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_summary);

        TextView tvTitle   = findViewById(R.id.tvResultTitle);
        TextView tvScore   = findViewById(R.id.tvScore);
        TextView tvInfo    = findViewById(R.id.tvInfo);
        Button   btnRetry  = findViewById(R.id.btnRetrySame);
        Button   btnHome   = findViewById(R.id.btnGoHome);
        Button   btnStats  = findViewById(R.id.btnStats);

        Intent intent = getIntent();
        boolean success      = intent.getBooleanExtra("success", false);
        long    score        = intent.getLongExtra("score", 0);
        long    elapsed      = intent.getLongExtra("elapsed", 0);
        int     mistakes     = intent.getIntExtra("mistakes", 0);
        String  difficulty   = intent.getStringExtra("difficulty");
        boolean newRecord    = intent.getBooleanExtra("newRecord", false);

        String diffLabel = "보통";
        if ("easy".equals(difficulty)) diffLabel = "쉬움";
        else if ("hard".equals(difficulty)) diffLabel = "어려움";

        tvTitle.setText(success ? "클리어!" : "실패...");
        tvScore.setText("점수 : " + score);

        long min = elapsed / 60;
        long sec = elapsed % 60;

        String info = "난이도 : " + diffLabel +
                "\n시간 : " + String.format("%02d:%02d", min, sec) +
                "\n실수 : " + mistakes + "회";

        if (newRecord) info += "\n\n🎉 최고 기록 갱신!";

        tvInfo.setText(info);

        // 간단 애니메이션
        tvTitle.setScaleX(0.7f);
        tvTitle.setScaleY(0.7f);
        tvTitle.setAlpha(0f);
        tvTitle.animate()
                .scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration(600)
                .start();

        final String diffFinal = difficulty;

        btnRetry.setOnClickListener(v -> {
            Intent i = new Intent(this, SudokuActivity.class);
            i.putExtra("difficulty", diffFinal);
            i.putExtra("continue", false);
            startActivity(i);
            finish();
        });

        btnHome.setOnClickListener(v -> {
            Intent i = new Intent(this, DifficultySelectActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
            finish();
        });

        btnStats.setOnClickListener(v -> {
            startActivity(new Intent(this, StatsActivity.class));
        });
    }
}
