package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

import androidx.appcompat.app.AppCompatDelegate;

public class SudokuPlusActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeManager.applyTheme(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plus);

        Button btnRandomTheme = findViewById(R.id.btnRandomTheme);
        Button btnStats       = findViewById(R.id.btnGoStats);
        Button btnAbout       = findViewById(R.id.btnGoAbout);

        btnRandomTheme.setOnClickListener(v -> {
            Random rnd = new Random();
            int mode = rnd.nextBoolean()
                    ? AppCompatDelegate.MODE_NIGHT_NO
                    : AppCompatDelegate.MODE_NIGHT_YES;
            ThemeManager.setTheme(this, mode);
            recreate();
        });

        btnStats.setOnClickListener(v ->
                startActivity(new Intent(this, StatsActivity.class)));

        btnAbout.setOnClickListener(v ->
                startActivity(new Intent(this, AboutActivity.class)));
    }
}
