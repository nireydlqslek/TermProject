package com.example.myapplication;  // ← 프로젝트 패키지에 맞게 수정

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.Arrays;
import java.util.Collections;
import java.util.Locale;
import java.util.Random;
import java.util.Stack;

public class SudokuActivity extends AppCompatActivity {

    private static final int SIZE = 9;

    private GridLayout gridLayout;
    private LinearLayout numLayout, topLayout;
    private TextView mistakeView, timerView;

    private TextView[][] cells = new TextView[SIZE][SIZE];

    private int[][] solution = new int[SIZE][SIZE];
    private int[][] puzzle   = new int[SIZE][SIZE];
    private int[][] user     = new int[SIZE][SIZE];

    // 숫자 색상 (파란/빨간 유지용)
    private int[][] colorBoard = new int[SIZE][SIZE];

    private int selectedRow = -1, selectedCol = -1;

    private int hintCount    = 3;
    private int undoCount    = 3;
    private int mistakeCount = 0;

    private boolean hintMode    = false;
    private boolean isGameActive = true;   // 게임이 끝났는지 여부

    private Stack<Move> undoStack = new Stack<>();

    // 난이도
    private String difficulty = "normal";
    private int removedCount  = 40;

    // 타이머 (0초부터 올라가고 limitSeconds 도달 시 게임 오버)
    private long limitSeconds   = 600;   // normal = 10분
    private long elapsedSeconds = 0;
    private CountDownTimer timer;

    // 점수 / 저장
    private SharedPreferences prefs;

    private Button hintButton, undoButton, eraseButton;

    // 되돌리기용
    private static class Move {
        int r, c;
        int oldValue, newValue;
        int oldColor;

        Move(int r, int c, int oldValue, int newValue, int oldColor) {
            this.r = r;
            this.c = c;
            this.oldValue = oldValue;
            this.newValue = newValue;
            this.oldColor = oldColor;
        }
    }

    // -----------------------------------------------------
    // 생명주기
    // -----------------------------------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sudoku);

        gridLayout = findViewById(R.id.gridLayout);
        numLayout = findViewById(R.id.numLayout);
        topLayout = findViewById(R.id.topLayout);

        mistakeView = findViewById(R.id.mistakeView);
        timerView = findViewById(R.id.timerView);  // ★ 반드시 있어야 함

        hintButton = findViewById(R.id.btnHint);
        undoButton = findViewById(R.id.btnUndo);
        eraseButton = findViewById(R.id.btnErase);

        createSudokuGrid();
        createNumberButtons();

        difficulty = getIntent().getStringExtra("difficulty");
        if (difficulty == null) difficulty = "normal";

        applyDifficultySettings();
        generatePuzzle();
        initBoardsForNewGame();
        displayPuzzleForNewGame();

        startTimer();  // ★ timerView가 null이 아닌 상태에서 실행됨
    }


    @Override
    protected void onPause() {
        super.onPause();
        // 게임이 진행 중일 때만 저장 (게임오버 후에는 저장 안 함)
        if (isGameActive) {
            saveGameState();
        }
        stopTimer();
    }

    // -----------------------------------------------------
    // 난이도 & 타이머
    // -----------------------------------------------------

    private void applyDifficultySettings() {
        switch (difficulty) {
            case "easy":
                removedCount = 30;   // 빈칸 30개
                limitSeconds = 300;  // 5분
                break;
            case "hard":
                removedCount = 50;   // 빈칸 50개
                limitSeconds = 900;  // 15분
                break;
            default: // normal
                removedCount = 40;   // 빈칸 40개
                limitSeconds = 600;  // 10분
                break;
        }
    }

    private void startTimer() {
        if (timer != null) timer.cancel();
        elapsedSeconds = 0;

        timer = new CountDownTimer(limitSeconds * 1000, 1000) {
            @Override
            public void onTick(long m) {
                long remain = m / 1000;
                elapsedSeconds = limitSeconds - remain;

                long min = elapsedSeconds / 60;
                long sec = elapsedSeconds % 60;

                timerView.setText(String.format(Locale.getDefault(),
                        "시간: %02d:%02d", min, sec));
            }

            @Override
            public void onFinish() {
                onTimeOver();
            }
        };
        timer.start();
    }

    private void restoreTimer() {
        if (timer != null) timer.cancel();

        long remain = limitSeconds - elapsedSeconds;
        if (remain <= 0) {
            onTimeOver();
            return;
        }

        timer = new CountDownTimer(remain * 1000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                long remain = millisUntilFinished / 1000;
                elapsedSeconds = limitSeconds - remain;

                long min = elapsedSeconds / 60;
                long sec = elapsedSeconds % 60;

                timerView.setText(String.format(Locale.getDefault(),
                        "시간: %02d:%02d", min, sec));
            }

            @Override
            public void onFinish() {
                onTimeOver();
            }
        };
        timer.start();
    }

    private void stopTimer() {
        if (timer != null) timer.cancel();
    }

    private void onTimeOver() {
        stopTimer();
        prefs.edit().putBoolean("game_saved", false).apply();

        // 실패 기록 저장
        SudokuStatsManager.recordGame(
                this, difficulty, limitSeconds, false
        );

        new AlertDialog.Builder(this)
                .setTitle("게임 오버")
                .setMessage("제한 시간을 초과했습니다.\n난이도를 다시 선택하세요.")
                .setCancelable(false)
                .setPositiveButton("메인 화면", (d, w) -> goToMain())
                .show();
    }


    // -----------------------------------------------------
    // 저장 / 불러오기
    // -----------------------------------------------------

    private void saveGameState() {
        SharedPreferences.Editor editor = prefs.edit();
        Gson gson = new Gson();

        editor.putBoolean("game_saved", true);

        editor.putString("saved_puzzle", gson.toJson(puzzle));
        editor.putString("saved_solution", gson.toJson(solution));
        editor.putString("saved_user", gson.toJson(user));
        editor.putString("saved_color", gson.toJson(colorBoard));

        editor.putLong("saved_timer", elapsedSeconds);
        editor.putInt("saved_mistake", mistakeCount);
        editor.putInt("saved_hint", hintCount);
        editor.putInt("saved_undo", undoCount);
        editor.putString("saved_diff", difficulty);

        editor.apply();
    }

    private int[][] safeLoadInt2D(String key) {
        String json = prefs.getString(key, null);
        if (json == null || json.isEmpty()) return null;

        try {
            return new Gson().fromJson(
                    json, new TypeToken<int[][]>() {}.getType()
            );
        } catch (Exception e) {
            return null;
        }
    }

    private boolean loadSavedGame() {
        if (!prefs.getBoolean("game_saved", false)) return false;

        int[][] pz  = safeLoadInt2D("saved_puzzle");
        int[][] sol = safeLoadInt2D("saved_solution");
        int[][] usr = safeLoadInt2D("saved_user");
        int[][] col = safeLoadInt2D("saved_color");

        if (pz == null || sol == null || usr == null || col == null)
            return false;

        puzzle     = pz;
        solution   = sol;
        user       = usr;
        colorBoard = col;

        elapsedSeconds = prefs.getLong("saved_timer", 0);
        mistakeCount   = prefs.getInt("saved_mistake", 0);
        hintCount      = prefs.getInt("saved_hint", 3);
        undoCount      = prefs.getInt("saved_undo", 3);
        difficulty     = prefs.getString("saved_diff", "normal");

        applyDifficultySettings();
        return true;
    }

    private void restoreFromSavedState() {
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                int v = user[r][c];
                int color = colorBoard[r][c];
                TextView cell = cells[r][c];

                if (v != 0) {
                    cell.setText(String.valueOf(v));
                    cell.setTextSize(18);
                    if (color == 0) color = Color.BLACK;
                    cell.setTextColor(color);
                } else {
                    cell.setText("");
                    cell.setTextSize(18);
                    cell.setTextColor(Color.BLACK);
                }
                cell.setBackgroundColor(Color.WHITE);
            }
        }

        mistakeView.setText("실수: " + mistakeCount + "/3");
        selectedRow = selectedCol = -1;
        updateHighlight();
    }

    private void restoreButtonTexts() {
        hintButton.setText("힌트 (" + hintCount + ")");
        undoButton.setText("되돌리기 (" + undoCount + ")");
    }

    // -----------------------------------------------------
    // 퍼즐 완료 / 점수
    // -----------------------------------------------------

    // 기존 checkPuzzleCompletion() 전체를 아래 코드로 교체

    private void checkPuzzleCompletion() {

        for (int r = 0; r < SIZE; r++)
            for (int c = 0; c < SIZE; c++)
                if (user[r][c] != solution[r][c])
                    return;

        stopTimer();
        prefs.edit().putBoolean("game_saved", false).apply();

        long score = 10000 - elapsedSeconds * 5;
        if (score < 0) score = 0;

        String key = "best_" + difficulty;
        long best = prefs.getLong(key, 0);

        boolean newRecord = score > best;
        if (newRecord) prefs.edit().putLong(key, score).apply();

        // 통계 저장 (성공)
        SudokuStatsManager.recordGame(
                this, difficulty, elapsedSeconds, true
        );

        // GameSummaryActivity로 이동
        Intent i = new Intent(this, GameSummaryActivity.class);
        i.putExtra("success", true);
        i.putExtra("score", score);
        i.putExtra("elapsed", elapsedSeconds);
        i.putExtra("mistakes", mistakeCount);
        i.putExtra("difficulty", difficulty);
        i.putExtra("newRecord", newRecord);
        startActivity(i);
        finish();
    }


    private void onMistakeGameOver() {
        isGameActive = false;
        stopTimer();
        prefs.edit().putBoolean("game_saved", false).apply();

        new AlertDialog.Builder(this)
                .setTitle("게임 오버")
                .setMessage("실수를 3회 하여 게임이 종료되었습니다.\n난이도를 다시 선택하세요.")
                .setCancelable(false)
                .setPositiveButton("메인 화면", (d, w) -> goToMain())
                .setNegativeButton("새 게임", (d, w) -> {
                    isGameActive = true;
                    showNewGameDialog();
                })
                .show();
    }

    private void addMistake() {
        mistakeCount++;
        mistakeView.setText("실수: " + mistakeCount + "/3");
        if (mistakeCount >= 3) {
            // 실패 통계 기록
            SudokuStatsManager.recordGame(
                    this, difficulty, elapsedSeconds, false
            );
            // 기존의 "게임 오버" 다이얼로그 표시 로직 그대로
        }

    }

    private void showNewGameDialog() {
        String[] labels = {"쉬움", "보통", "어려움"};
        String[] values = {"easy", "normal", "hard"};

        new AlertDialog.Builder(this)
                .setTitle("난이도 선택")
                .setItems(labels, (dialog, which) -> {
                    difficulty = values[which];
                    applyDifficultySettings();
                    isGameActive = true;
                    resetGame();
                })
                .show();
    }

    private void resetGame() {
        hintCount    = 3;
        undoCount    = 3;
        mistakeCount = 0;
        mistakeView.setText("실수: 0/3");
        undoStack.clear();
        selectedRow = selectedCol = -1;

        generatePuzzle();
        initBoardsForNewGame();
        displayPuzzleForNewGame();
        startTimer();
        restoreButtonTexts();
    }

    private void goToMain() {
        Intent intent = new Intent(this, DifficultySelectActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }

    // -----------------------------------------------------
    // UI 공통
    // -----------------------------------------------------

    private void applyFlat(Button b) {
        b.setBackgroundColor(Color.parseColor("#EDEDED"));
        b.setElevation(0);
        b.setStateListAnimator(null);
    }

    private void createHintButton() {
        hintButton = new Button(this);
        hintButton.setText("힌트💡 (3)");
        hintButton.setTextSize(16);
        applyFlat(hintButton);

        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(dp(95), dp(55));
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));

        hintButton.setLayoutParams(lp);
        hintButton.setGravity(Gravity.CENTER);
        hintButton.setPadding(0, 0, 0, 0);

        hintButton.setOnClickListener(v -> {
            if (!isGameActive) return;

            if (hintCount == 0) {
                Toast.makeText(this, "힌트 없음!", Toast.LENGTH_SHORT).show();
                return;
            }
            hintMode = true;
            Toast.makeText(this, "힌트 넣을 칸을 선택하세요", Toast.LENGTH_SHORT).show();
        });

        topLayout.addView(hintButton);
    }

    private void createUndoButton() {
        undoButton = new Button(this);
        undoButton.setText("되돌리기↩ (3)");
        undoButton.setTextSize(16);
        applyFlat(undoButton);

        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(dp(95), dp(55));
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));

        undoButton.setLayoutParams(lp);
        undoButton.setGravity(Gravity.CENTER);
        undoButton.setPadding(0, 0, 0, 0);

        undoButton.setOnClickListener(v -> {
            if (!isGameActive) return;

            if (undoCount == 0) {
                Toast.makeText(this, "되돌리기 없음!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (undoStack.isEmpty()) {
                Toast.makeText(this, "기록 없음!", Toast.LENGTH_SHORT).show();
                return;
            }

            Move mv = undoStack.pop();

            // 틀린 숫자를 되돌리면 실수 카운트 감소
            if (mv.newValue != 0 && mv.newValue != solution[mv.r][mv.c]) {
                if (mistakeCount > 0) {
                    mistakeCount--;
                    mistakeView.setText("실수: " + mistakeCount + "/3");
                }
            }

            user[mv.r][mv.c] = mv.oldValue;
            colorBoard[mv.r][mv.c] = mv.oldColor;

            TextView cell = cells[mv.r][mv.c];
            if (mv.oldValue != 0) {
                cell.setText(String.valueOf(mv.oldValue));
                cell.setTextSize(18);
                cell.setTextColor(mv.oldColor == 0 ? Color.BLACK : mv.oldColor);
            } else {
                cell.setText("");
                cell.setTextSize(18);
                cell.setTextColor(Color.BLACK);
            }

            undoCount--;
            undoButton.setText("되돌리기↩ (" + undoCount + ")");
            updateHighlight();
        });

        topLayout.addView(undoButton);
    }

    private void createEraseButton() {
        Button erase = new Button(this);
        erase.setText("지우기");
        erase.setTextSize(16);
        applyFlat(erase);

        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(dp(95), dp(55));
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));

        erase.setLayoutParams(lp);
        erase.setGravity(Gravity.CENTER);
        erase.setPadding(0, 0, 0, 0);

        erase.setOnClickListener(v -> {
            if (!isGameActive) return;
            if (selectedRow == -1) return;

            int r = selectedRow;
            int c = selectedCol;

            // 원래 문제 숫자는 지우지 않음
            if (puzzle[r][c] != 0 && user[r][c] == puzzle[r][c]) return;

            int oldValue = user[r][c];
            int oldColor = colorBoard[r][c];

            undoStack.push(new Move(r, c, oldValue, 0, oldColor));

            user[r][c] = 0;
            colorBoard[r][c] = 0;

            TextView cell = cells[r][c];
            cell.setText("");
            cell.setTextSize(18);
            cell.setTextColor(Color.BLACK);

            updateHighlight();
        });

        topLayout.addView(erase);
    }

    // -----------------------------------------------------
    // 셀 선택 / 숫자 입력 / 하이라이트
    // -----------------------------------------------------

    private void selectCell(int r, int c) {
        if (!isGameActive) return;

        if (hintMode) {
            if (puzzle[r][c] != 0) {
                Toast.makeText(this, "기본 칸에는 힌트 사용 불가", Toast.LENGTH_SHORT).show();
                return;
            }

            int oldValue = user[r][c];
            int oldColor = colorBoard[r][c];
            int newValue = solution[r][c];

            undoStack.push(new Move(r, c, oldValue, newValue, oldColor));

            user[r][c] = newValue;
            colorBoard[r][c] = Color.BLUE;

            TextView cell = cells[r][c];
            cell.setText(String.valueOf(newValue));
            cell.setTextSize(18);
            cell.setTextColor(Color.BLUE);

            hintCount--;
            hintButton.setText("힌트💡 (" + hintCount + ")");
            hintMode = false;

            selectedRow = r;
            selectedCol = c;
            updateHighlight();
            checkPuzzleCompletion();
            return;
        }

        selectedRow = r;
        selectedCol = c;
        updateHighlight();
    }

    private void inputNumber(int num) {
        if (!isGameActive) return;
        if (selectedRow == -1) return;

        // 새 입력마다 모든 배경 초기화 (이전에 남은 빨간 배경 제거)
        for (int rr = 0; rr < 9; rr++)
            for (int cc = 0; cc < 9; cc++)
                cells[rr][cc].setBackgroundColor(Color.WHITE);

        int r = selectedRow;
        int c = selectedCol;

        // 기본 문제 숫자는 수정 불가
        if (puzzle[r][c] != 0 && user[r][c] == puzzle[r][c]) {
            updateHighlight();
            return;
        }

        TextView cell = cells[r][c];

        int oldValue = user[r][c];
        int oldColor = colorBoard[r][c];

        user[r][c] = num;

        // ----------------------------
        // ① 규칙 위반(중복) 체크
        // ----------------------------
        boolean ruleConflict = false;

        // 행 검사
        for (int i = 0; i < 9; i++) {
            if (i != c && user[r][i] == num) ruleConflict = true;
        }

        // 열 검사
        for (int i = 0; i < 9; i++) {
            if (i != r && user[i][c] == num) ruleConflict = true;
        }

        // 3×3 박스 검사
        int sr = (r / 3) * 3;
        int sc = (c / 3) * 3;
        for (int i = sr; i < sr + 3; i++) {
            for (int j = sc; j < sc + 3; j++) {
                if (!(i == r && j == c) && user[i][j] == num) ruleConflict = true;
            }
        }

        // ----------------------------
        // ② CASE 2: 규칙 위반 (중복 발생)
        // ----------------------------
        if (ruleConflict) {

            undoStack.push(new Move(r, c, oldValue, num, oldColor));

            // 입력 숫자 설정
            cell.setText(String.valueOf(num));
            cell.setTextSize(18);
            cell.setTextColor(Color.RED);
            colorBoard[r][c] = Color.RED;

            int redBg = Color.parseColor("#FFCDD2");

            // 행 충돌
            for (int i = 0; i < 9; i++)
                if (user[r][i] == num)
                    cells[r][i].setBackgroundColor(redBg);

            // 열 충돌
            for (int i = 0; i < 9; i++)
                if (user[i][c] == num)
                    cells[i][c].setBackgroundColor(redBg);

            // 3×3 박스 충돌
            for (int i = sr; i < sr + 3; i++)
                for (int j = sc; j < sc + 3; j++)
                    if (user[i][j] == num)
                        cells[i][j].setBackgroundColor(redBg);

            // 실수 카운트
            addMistake();
            return; // CASE2 끝
        }

        // ----------------------------
        // ③ CASE 1: 규칙 위반은 없지만 → 정답과 비교했을 때 틀린 경우
        // ----------------------------
        if (num != solution[r][c]) {

            undoStack.push(new Move(r, c, oldValue, num, oldColor));

            cell.setText(String.valueOf(num));
            cell.setTextSize(18);
            cell.setTextColor(Color.RED);
            colorBoard[r][c] = Color.RED;

            addMistake();

            // 같은 숫자 파란 배경 하이라이트만 정상적으로 다시 그림
            updateHighlight();
            return;
        }

        // ----------------------------
        // ④ 정답인 경우
        // ----------------------------
        undoStack.push(new Move(r, c, oldValue, num, oldColor));

        cell.setText(String.valueOf(num));
        cell.setTextSize(18);
        cell.setTextColor(Color.BLUE);
        colorBoard[r][c] = Color.BLUE;

        updateHighlight();
        checkPuzzleCompletion();
    }

    private void updateHighlight() {

        // 1) 기본 배경(흰색)으로 초기화
        for (int r = 0; r < SIZE; r++)
            for (int c = 0; c < SIZE; c++)
                cells[r][c].setBackgroundColor(Color.WHITE);

        // 선택 칸 없음 → 종료
        if (selectedRow == -1) return;

        int rSel = selectedRow;
        int cSel = selectedCol;
        int value = user[rSel][cSel];

        // ------------------------------
        // 🔥 CASE A: 충돌이 있는 경우
        // ------------------------------
        boolean conflict = false;

        // 행 검사
        for (int i = 0; i < 9; i++) {
            if (i != cSel && user[rSel][i] == value) conflict = true;
        }

        // 열 검사
        for (int i = 0; i < 9; i++) {
            if (i != rSel && user[i][cSel] == value) conflict = true;
        }

        // 박스 검사
        int sr = (rSel / 3) * 3;
        int sc = (cSel / 3) * 3;
        for (int r = sr; r < sr + 3; r++)
            for (int c = sc; c < sc + 3; c++)
                if (!(r == rSel && c == cSel) && user[r][c] == value)
                    conflict = true;

        // 충돌이 있다면 → 빨간색 강조만 유지
        if (conflict) {
            int redBg = Color.parseColor("#FFCDD2");

            // 충돌한 칸들 빨간색
            for (int i = 0; i < 9; i++)
                if (user[rSel][i] == value)
                    cells[rSel][i].setBackgroundColor(redBg);

            for (int i = 0; i < 9; i++)
                if (user[i][cSel] == value)
                    cells[i][cSel].setBackgroundColor(redBg);

            for (int r = sr; r < sr + 3; r++)
                for (int c = sc; c < sc + 3; c++)
                    if (user[r][c] == value)
                        cells[r][c].setBackgroundColor(redBg);

            return; // ⛔ 파란색 하이라이트는 표시하지 않음
        }


        // ------------------------------
        // 🔵 CASE B: 충돌 없음 → 파란색 하이라이트 적용
        // ------------------------------

        int rowColColor   = Color.parseColor("#E8F2FF"); // 연파랑(행/열/박스)
        int sameNumColor  = Color.parseColor("#D6E9FF"); // 더 진한 파란색(같은 숫자)
        int selectedColor = Color.parseColor("#BBDEFB"); // 선택된 칸(가장 진함)

        // 행/열/박스 하이라이트
        for (int i = 0; i < SIZE; i++) {
            cells[rSel][i].setBackgroundColor(rowColColor);
            cells[i][cSel].setBackgroundColor(rowColColor);
        }

        for (int r = sr; r < sr + 3; r++)
            for (int c = sc; c < sc + 3; c++)
                cells[r][c].setBackgroundColor(rowColColor);

        // 같은 숫자는 전체 연한 파란색
        if (value != 0) {
            for (int r = 0; r < SIZE; r++)
                for (int c = 0; c < SIZE; c++)
                    if (user[r][c] == value)
                        cells[r][c].setBackgroundColor(sameNumColor);
        }

        // 선택된 칸은 가장 진한 파란색
        cells[rSel][cSel].setBackgroundColor(selectedColor);
    }


    // -----------------------------------------------------
    // 숫자 버튼 / 그리드 생성
    // -----------------------------------------------------

    private void createNumberButtons() {
        for (int n = 1; n <= 9; n++) {
            Button b = new Button(this);
            b.setText(String.valueOf(n));
            b.setTextSize(18);
            applyFlat(b);

            LinearLayout.LayoutParams lp =
                    new LinearLayout.LayoutParams(dp(60), dp(45));
            lp.setMargins(dp(5), 0, dp(5), 0);
            b.setLayoutParams(lp);

            final int num = n;
            b.setOnClickListener(v -> inputNumber(num));

            numLayout.addView(b);
        }
    }

    private void createSudokuGrid() {
        int thin = dp(1);     // 일반 칸
        int medium = dp(2);   // 3×3 경계
        int thick = dp(4);    // 바깥 굵기
        int cellSize = dp(42); // 버튼 내려와 있으니 조금 키우면 더 안정적

        gridLayout.removeAllViews();
        gridLayout.setRowCount(SIZE);
        gridLayout.setColumnCount(SIZE);
        gridLayout.setAlignmentMode(GridLayout.ALIGN_BOUNDS);

        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {

                TextView tv = new TextView(this);
                tv.setText("");
                tv.setTextSize(20);
                tv.setGravity(Gravity.CENTER);
                tv.setIncludeFontPadding(false);
                tv.setBackgroundColor(Color.WHITE);
                tv.setClickable(true);
                tv.setStateListAnimator(null);
                tv.setElevation(0);

                int rr = r, cc = c;
                tv.setOnClickListener(v -> selectCell(rr, cc));

                GridLayout.LayoutParams p = new GridLayout.LayoutParams();
                p.width = cellSize;
                p.height = cellSize;

                // 디폴트는 얇은 선
                int top = thin;
                int left = thin;
                int right = thin;
                int bottom = thin;

                // 바깥 테두리
                if (r == 0) top = thick;
                if (c == 0) left = thick;
                if (r == 8) bottom = thick;
                if (c == 8) right = thick;

                // 3×3 박스 경계선
                if (r % 3 == 0 && r != 0) top = medium;
                if (c % 3 == 0 && c != 0) left = medium;

                p.setMargins(left, top, right, bottom);
                gridLayout.addView(tv, p);

                cells[r][c] = tv;
            }
        }
    }

    // -----------------------------------------------------
    // 퍼즐 생성 / 출력
    // -----------------------------------------------------

    private void generatePuzzle() {
        boolean ok = false;
        int tries = 0;

        while (!ok && tries < 5) {
            clearBoard(solution);
            ok = fillBoard(solution, 0, 0);
            tries++;
        }

        copyBoard(solution, puzzle);

        Random rnd = new Random();
        int removed = 0;
        while (removed < removedCount) {
            int r = rnd.nextInt(SIZE);
            int c = rnd.nextInt(SIZE);
            if (puzzle[r][c] != 0) {
                puzzle[r][c] = 0;
                removed++;
            }
        }
    }

    private void initBoardsForNewGame() {
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                user[r][c] = puzzle[r][c];
                colorBoard[r][c] = 0;
            }
        }
    }

    private void displayPuzzleForNewGame() {
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                int v = puzzle[r][c];
                TextView cell = cells[r][c];

                if (v == 0) {
                    cell.setText("");
                } else {
                    cell.setText(String.valueOf(v));
                    cell.setTextColor(Color.BLACK);
                }
                cell.setTextSize(18);
                cell.setBackgroundColor(Color.WHITE);
            }
        }

        mistakeView.setText("실수: 0/3");
        selectedRow = selectedCol = -1;
        updateHighlight();
    }

    // 백트래킹으로 정답판 생성
    private boolean fillBoard(int[][] b, int r, int c) {
        if (r == SIZE) return true;

        int nr = (c == SIZE - 1) ? r + 1 : r;
        int nc = (c == SIZE - 1) ? 0 : c + 1;

        Integer[] nums = {1,2,3,4,5,6,7,8,9};
        Collections.shuffle(Arrays.asList(nums));

        for (int n : nums) {
            if (isValidPlacement(b, r, c, n)) {
                b[r][c] = n;
                if (fillBoard(b, nr, nc)) return true;
                b[r][c] = 0;
            }
        }
        return false;
    }

    private boolean isValidPlacement(int[][] b, int r, int c, int n) {
        for (int i = 0; i < SIZE; i++)
            if (b[r][i] == n || b[i][c] == n) return false;

        int sr = (r / 3) * 3;
        int sc = (c / 3) * 3;

        for (int i = sr; i < sr + 3; i++)
            for (int j = sc; j < sc + 3; j++)
                if (b[i][j] == n) return false;

        return true;
    }

    private void clearBoard(int[][] b) {
        for (int[] row : b) Arrays.fill(row, 0);
    }

    private void copyBoard(int[][] s, int[][] d) {
        for (int i = 0; i < SIZE; i++)
            System.arraycopy(s[i], 0, d[i], 0, SIZE);
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                v,
                getResources().getDisplayMetrics()
        );
    }
}
