package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class StatsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeManager.applyTheme(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);

        TextView tvSummary = findViewById(R.id.tvStatsSummary);
        Button btnReset = findViewById(R.id.btnResetStats);

        SudokuStatsManager.Stats s = SudokuStatsManager.loadStats(this);

        double avgTime = (s.totalPlays == 0) ?
                0 : (double) s.totalTime / s.totalPlays;

        long avgSec = (long) avgTime;
        long min = avgSec / 60;
        long sec = avgSec % 60;

        String text = "총 플레이 : " + s.totalPlays +
                "\n클리어 수 : " + s.totalWins +
                "\n\n난이도별 플레이 수" +
                "\n  쉬움 : " + s.easyPlays +
                "\n  보통 : " + s.normalPlays +
                "\n  어려움 : " + s.hardPlays +
                "\n\n평균 소요 시간 : " +
                String.format("%02d:%02d", min, sec);

        tvSummary.setText(text);

        btnReset.setOnClickListener(v -> {
            SudokuStatsManager.resetAll(this);
            recreate();
        });
    }
}
