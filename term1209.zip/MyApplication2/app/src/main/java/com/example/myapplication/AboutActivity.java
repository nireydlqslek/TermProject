package com.example.myapplication;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        TextView tv = findViewById(R.id.tvAbout);

        // ⭐ BuildConfig 없이 버전 가져오기 (가장 안정적)
        String version;
        try {
            version = getPackageManager()
                    .getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            version = "1.0";
        }

        String text = "Sudoku App\n\n"
                + "개발자 : 김예린\n"
                + "버전 : " + version + "\n\n"
                + "이 앱은 안드로이드 스튜디오 & Java로 작성된\n"
                + "스도쿠 학기말 프로젝트입니다.";

        tv.setText(text);
    }
}
