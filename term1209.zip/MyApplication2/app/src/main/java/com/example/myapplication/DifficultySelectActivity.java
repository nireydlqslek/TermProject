package com.example.myapplication;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class DifficultySelectActivity extends AppCompatActivity {

    private Button easyBtn, normalBtn, hardBtn, continueBtn, themeBtn, plusBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeManager.applyTheme(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_difficulty_select);

        easyBtn     = findViewById(R.id.btnEasy);
        normalBtn   = findViewById(R.id.btnNormal);
        hardBtn     = findViewById(R.id.btnHard);
        continueBtn = findViewById(R.id.btnContinue);
        themeBtn    = findViewById(R.id.btnTheme);
        plusBtn     = findViewById(R.id.btnPlus);

        styleButton(easyBtn);
        styleButton(normalBtn);
        styleButton(hardBtn);
        styleButton(continueBtn);
        styleButton(themeBtn);
        styleButton(plusBtn);

        easyBtn.setOnClickListener(v -> {
            Intent intent = new Intent(this, SudokuActivity.class);
            intent.putExtra("difficulty", "easy");
            startActivity(intent);
        });

        normalBtn.setOnClickListener(v -> {
            Intent intent = new Intent(this, SudokuActivity.class);
            intent.putExtra("difficulty", "normal");
            startActivity(intent);
        });

        hardBtn.setOnClickListener(v -> {
            Intent intent = new Intent(this, SudokuActivity.class);
            intent.putExtra("difficulty", "hard");
            startActivity(intent);
        });


        continueBtn.setOnClickListener(v -> showContinueDialog());

        themeBtn.setOnClickListener(v -> {
            ThemeManager.toggleTheme(this);
            recreate();
        });

        plusBtn.setOnClickListener(v ->
                startActivity(new Intent(this, SudokuPlusActivity.class)));
    }

    private void styleButton(Button b) {
        if (b == null) return;
        b.setBackgroundResource(R.drawable.round_purple_button);
        b.setTextColor(0xFFFFFFFF);
    }

    private void startGame(String diff) {
        Intent intent = new Intent(this, SudokuActivity.class);
        intent.putExtra("difficulty", "easy");   // ← key 이름 "difficulty"
        startActivity(intent);
        intent.putExtra("difficulty", diff);
        intent.putExtra("continue", false);
        startActivity(intent);
    }

    private void showContinueDialog() {
        SharedPreferences prefs = getSharedPreferences("sudoku_prefs", MODE_PRIVATE);
        boolean saved = prefs.getBoolean("game_saved", false);

        if (!saved) {
            new AlertDialog.Builder(this)
                    .setTitle("이어하기 없음")
                    .setMessage("저장된 게임이 없습니다.")
                    .setPositiveButton("확인", null)
                    .show();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("이어하기")
                .setMessage("이전 게임을 이어서 하시겠습니까?")
                .setNegativeButton("아니오", null)
                .setPositiveButton("예", (dialog, which) -> {
                    Intent i = new Intent(this, SudokuActivity.class);
                    i.putExtra("continue", true);
                    startActivity(i);
                })
                .show();
    }
}